function PN_model=GSPN1()

%Make null PN model
[PN_model] = Init_PN('GSPN1');

%Define Places
%---------------------------------------------------------------
% [PN_model,Pl_num]=New_Place(PN_model,Name,Cap,Type,Marking)
%---------------------------------------------------------------
[PN_model,p1]=New_Place(PN_model,'P1',0,1,{});
[PN_model,p2]=New_Place(PN_model,'P2',0,1,{});
[PN_model,p3]=New_Place(PN_model,'P3',0,0,{[0,0,0,0]});
[PN_model,p4]=New_Place(PN_model,'P4',0,1,{});
[PN_model,p5]=New_Place(PN_model,'P5',0,0,{[0,0,0,0]});


%Define Transitions
%---------------------------------------------------------------
%[PN_model,Tr_num]=New_Transition(PN_model, Name, Firing_func_name, Type=0/1/2, TrValue=0/TrDly/Rate, TknDly, Priority, Probability)
%Type=0:Immediate 1:Timed 2:Stochastic 
%---------------------------------------------------------------
[PN_model,t1]=New_Transition(PN_model,'T1', 'General_func',0,0,0,1,3);
[PN_model,t2]=New_Transition(PN_model,'T2', 'General_func',2,5,0,1,1);
[PN_model,t3]=New_Transition(PN_model,'T3', 'General_func',2,20,0,1,1);
[PN_model,t4]=New_Transition(PN_model,'T4', 'General_func',0,0,0,1,1);


%Add Communication Arcs
PN_model=Arc_T2P(PN_model,t1,p1);
PN_model=Arc_P2T(PN_model,p1,t2);
PN_model=Arc_T2P(PN_model,t2,p2);
PN_model=Arc_P2T(PN_model,p2,t3);
PN_model=Arc_T2P(PN_model,t3,p3);
PN_model=Arc_T2P(PN_model,t3,p4);
PN_model=Arc_P2T(PN_model,p4,t4);
PN_model=Arc_T2P(PN_model,t4,p5);
PN_model=Arc_P2T(PN_model,p5,t2);
PN_model=Arc_P2T(PN_model,p3,t1);

% [mat,shape,label]=make_biograph_matrix_from_PN_model(PN_model);
% Draw_PN_Model(PN_model);

