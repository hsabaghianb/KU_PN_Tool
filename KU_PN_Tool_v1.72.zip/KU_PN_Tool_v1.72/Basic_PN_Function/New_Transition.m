function [PN_model,Tr_num]=New_Transition(PN_model,Name,Firing_func_name,Type,TrValue,TknDly,Priority,Probability)
%---------------------------------------------------------------
%[PN_model,Tr_num]=New_Transition(PN_model, Name, Firing_func_name, Type=0/1/2, TrValue=0/TrDly/Rate, TknDly, Priority, Probability)
%Type=0:Immediate 1:Timed 2:Stochastic 
%---------------------------------------------------------------

Tr_num=numel(PN_model.T)+1;
t=null_model_PN(Name);
% t=Init_PN(Name);
if Tr_num==1
    PN_model.low_level_model=t;    
else
    PN_model.low_level_model(Tr_num)=t;
end

PN_model.T=[PN_model.T;{Name}];
PN_model.Firing_func=[PN_model.Firing_func; {Firing_func_name}];                  
PN_model.Tr_Type=[PN_model.Tr_Type,Type];

if Type==0  %Immediate
    PN_model.Delay=[PN_model.Delay,0];
    PN_model.Rate=[PN_model.Rate,0];
elseif Type==1 %Timed
    PN_model.Delay=[PN_model.Delay,TrValue];
    PN_model.Rate=[PN_model.Rate,0];
elseif Type==2 %Stochastic
    PN_model.Rate=[PN_model.Rate,TrValue];
    PN_model.Delay=[PN_model.Delay,exprnd(1/TrValue);];
else
    errmsg=['Error:Transition Type ', num2str(Type), ' is unknown! (in transition ''', Name, ''')'];
    error(errmsg);
end

PN_model.Priority=[PN_model.Priority,Priority];
PN_model.ProbWeight=[PN_model.ProbWeight,Probability];

    
t.Delay=[];             
t.Rate=[];              
t.ProbWeight=[];        



PN_model.TknDly=[PN_model.TknDly,TknDly];
PN_model.PPre=[PN_model.PPre,{[]}];
PN_model.Pre_Weight=[PN_model.Pre_Weight,{[]}];
PN_model.InhPre_Weight=[PN_model.InhPre_Weight,{[]}];
PN_model.InhPPre=[PN_model.InhPPre,{[]}];
PN_model.PPost=[PN_model.PPost,{[]}];
PN_model.Post_Weight=[PN_model.Post_Weight,{[]}];
PN_model.address=[PN_model.address;0];
PN_model.Comment=[PN_model.Comment;{''}];
