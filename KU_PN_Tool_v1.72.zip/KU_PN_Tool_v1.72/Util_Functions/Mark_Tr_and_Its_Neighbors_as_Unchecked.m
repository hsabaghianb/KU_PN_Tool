function PN_model=Mark_Tr_and_Its_Neighbors_as_Unchecked(PN_model,fired_Tr)
%    updated_place=[PN_model.PPre{fired_Tr},PN_model.PPost{fired_Tr}];
%    for p=updated_place
%        PN_model.Tr_State(PN_model.Cns{p})=8;
%        if PN_model.Cap(p)>0  %if capacitance of place is limited
%           PN_model.Tr_State(PN_model.Prd{p})=8;
%        end
%    end
   Post_place=PN_model.PPost{fired_Tr};
   Pre_place=PN_model.PPre{fired_Tr};
   for p=Post_place   
       for Tr=PN_model.Cns{p}
           if PN_model.Tr_State(Tr)==0
              PN_model.Tr_State(Tr)=8;   %mark all 0 state consumer Tr to unchecked 8
           end
       end 
       if PN_model.Cap(p)>0  %if capacitance of place is limited
          PN_model.Tr_State(PN_model.Prd{p})=8;
       end
   end
   for p=Pre_place
       for Tr=PN_model.Cns{p}
           if PN_model.Tr_State(Tr)~=0
              PN_model.Tr_State(Tr)=8;  %mark all non-zero state consumer Tr to unchecked 8
           end
       end 
       PN_model.Tr_State(PN_model.Cns{p})=8;
       if PN_model.Cap(p)>0  %if capacitance of place is limited
          PN_model.Tr_State(PN_model.Prd{p})=8;
       end
   end

   
end