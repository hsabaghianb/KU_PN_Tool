function Draw_TRMG_with_Probability_over_Time_on_Arc(TRMG)

bg = biograph(TRMG.A);

%set node label
for i=1:numel(bg.nodes)
    label=num2str(i);
    label=[label,'-'];
    bg.nodes(i).shape='circle';
    
    bg.nodes(i).Color=[1,1,1];
    bg.nodes(i).LineColor=[0,0,0];
    bg.nodes(i).TextColor=[0,0,0];
    if numel(find(i==TRMG.VS))>0
        bg.nodes(i).LineWidth=0.3;
    else
        bg.nodes(i).LineWidth=1.5;        
    end
    
    for j=1:numel(TRMG.RM(:,i))
        str1=num2str(TRMG.RM(j,i));
        if (numel(str1)>1)
           str1=['(',str1,')'];
        end
        label=strcat(label, str1);
    end
    
    bg.nodes(i).Label=label;    
end
bg.ShowWeights='on'; %Weight is transition number that initialized 
                     %by non-zero elements of TRMG.A while creating 
                     %bg by fumction call "bg = biograph(TRMG.A):" 

% set edge Weights with time to fire
k=1;
for i=1:numel(bg.nodes)
    for j=1:numel(bg.nodes)
        if TRMG.A(i,j)~=0 
            if TRMG.D(i,j)==0
               bg.Edges(k).Weight=100000;       %this is invalid and should not be occured
            else
               bg.Edges(k).Weight=TRMG.Pr(i,j)/TRMG.D(i,j);
            end
           k=k+1;
        end
    end
end
h = view(bg);




