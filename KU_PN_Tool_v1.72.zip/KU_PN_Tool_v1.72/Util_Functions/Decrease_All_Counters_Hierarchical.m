function PN_model=Decrease_All_Counters_Hierarchical(PN_model,num_of_skip_tick)
% if numel(PN_model.Enabled_Tr)==0
%     PN_model.Enabled_Tr=zeros(1,numel(PN_model.T));
% end
Enable_Timed_Tr=PN_model.Enabled_Tr==1 & PN_model.Tr_Type;
Should_Get_Zero=Enable_Timed_Tr & PN_model.CountT<num_of_skip_tick;
Should_be_decrement=Enable_Timed_Tr & PN_model.CountT>=num_of_skip_tick;
if any (Should_Get_Zero)
   'Error:num_of_skip_tick is too big' 
end;
PN_model.CountT=((PN_model.CountT-num_of_skip_tick).*(Should_be_decrement)) + (PN_model.CountT.*(~Should_be_decrement)); 
PN_model.CountT=PN_model.CountT.*(~Should_Get_Zero); 
for Tr=1:numel(PN_model.T)
    if numel(PN_model.low_level_model(Tr).T)>0
       PN_model.low_level_model(Tr)=Decrease_All_Counters_Hierarchical(PN_model.low_level_model(Tr),num_of_skip_tick);
    end
end

