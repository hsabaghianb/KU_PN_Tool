function PN_model = Gosasteh_mantghi()
[PN_model] = null_model_PN('Gosasteh_mantghi');

[PN_model,p11] = New_Place(PN_model,'gosaste',0,1,{});   %
[PN_model,Ptak11] = New_Place(PN_model,'gosaste_taking',0,1,{});   %
[PN_model,GP] = New_Place(PN_model,'gosaste_pass',0,1,{});   %

[PN_model,p14] = New_Place(PN_model,'manteghi',0,1,{});   %
[PN_model,Ptak14] = New_Place(PN_model,'manteghi_taking',0,1,{});   %
[PN_model,MP] = New_Place(PN_model,'manteghi_pass',0,1,{});   %


[PN_model,t11] = New_Transition(PN_model,'gosaste_taking_t1', 'General_func',1,5,0,1,90);	%
[PN_model,t5511] = New_Transition(PN_model,'gosaste_taking_t2', 'General_func',1,5,0,1,90);	%
[PN_model,tT11] = New_Transition(PN_model,'gosaste_taking_s', 'General_func',1,5,0,1,90);	%
[PN_model,Tpas11] = New_Transition(PN_model,'gosaste_passing', 'General_func',1,5,0,1,5);	%
[PN_model,Tfai11] = New_Transition(PN_model,'gosaste_failling', 'General_func',1,5,0,1,2);	%

[PN_model,t14] = New_Transition(PN_model,'manteghi_taking_t1', 'General_func',1,5,0,1,90);	%
[PN_model,t5514] = New_Transition(PN_model,'manteghi_taking_t2', 'General_func',1,5,0,1,90);	%
[PN_model,tT14] = New_Transition(PN_model,'manteghi_taking_s', 'General_func',1,5,0,1,90);	%
[PN_model,Tpas14] = New_Transition(PN_model,'manteghi_passing', 'General_func',1,5,0,1,5);	%
[PN_model,Tfai14] = New_Transition(PN_model,'manteghi_failling', 'General_func',1,5,0,1,2);	%

PN_model = Weighted_Arc_P2T(PN_model,p11,t11,2);	%PRESENT_PT_gosaste
PN_model = Weighted_Arc_T2P(PN_model,t11,Ptak11,1);	%TAKING_TP_gosaste
PN_model = Weighted_Arc_P2T(PN_model,p11,t5511,2);	%PRESENT_PT_gosaste
PN_model = Weighted_Arc_T2P(PN_model,t5511,Ptak11,1);	%TAKING_TP_gosaste
PN_model = Weighted_Arc_P2T(PN_model,p11,tT11,2);	%PRESENT_PT_gosaste
PN_model = Weighted_Arc_T2P(PN_model,tT11,Ptak11,1);	%TAKING_TP_gosaste
PN_model = Weighted_Arc_P2T(PN_model,Ptak11,Tpas11,1);	%Passing_PT_gosaste
PN_model = Weighted_Arc_P2T(PN_model,Ptak11,Tfai11,1);	%Failling_PT_gosaste
PN_model = Weighted_Arc_T2P(PN_model,Tpas11,GP,3);	%pass_gosaste
PN_model = Weighted_Arc_T2P(PN_model,Tfai11,p11,2);	%Failling_gosaste

PN_model = Weighted_Arc_P2T(PN_model,p14,t14,1);	%PRESENT_PT_manteghi
PN_model = Weighted_Arc_T2P(PN_model,t14,Ptak14,1);	%TAKING_TP_manteghi
PN_model = Weighted_Arc_P2T(PN_model,p14,t5514,1);	%PRESENT_PT_manteghi
PN_model = Weighted_Arc_T2P(PN_model,t5514,Ptak14,1);	%TAKING_TP_manteghi
PN_model = Weighted_Arc_P2T(PN_model,p14,tT14,1);	%PRESENT_PT_manteghi
PN_model = Weighted_Arc_T2P(PN_model,tT14,Ptak14,1);	%TAKING_TP_manteghi
PN_model = Weighted_Arc_P2T(PN_model,Ptak14,Tpas14,1);	%Passing_PT_manteghi
PN_model = Weighted_Arc_P2T(PN_model,Ptak14,Tfai14,1);	%Failling_PT_manteghi
PN_model = Weighted_Arc_T2P(PN_model,Tpas14,MP,3);	%pass_manteghi
PN_model = Weighted_Arc_T2P(PN_model,Tfai14,p14,1);	%Failling_manteghi

[PN_model,Phamch14_11] = New_Place(PN_model,'Phamch14_11',0,1,{[0,1,0,0]});
[PN_model,P1ham14_11] = New_Place(PN_model,'P1ham14_11',0,1,{});
[PN_model,P2ham14_11] = New_Place(PN_model,'P2ham14_11',0,1,{});
[PN_model,T1ham14_11] = New_Transition(PN_model,'hamniyaz_h_14_11','General_func',1,0,0,1,1);
[PN_model,T2ham14_11] = New_Transition(PN_model,'hamniyaz_h_14_11','General_func',1,0,0,1,1);
PN_model = Arc_T2P(PN_model,t11,P1ham14_11);
PN_model = Arc_T2P(PN_model,t5511,P2ham14_11);
PN_model = Arc_P2T(PN_model,P1ham14_11,T1ham14_11);
PN_model = Arc_P2T(PN_model,P2ham14_11,T2ham14_11);
PN_model = Arc_P2T(PN_model,Phamch14_11,T1ham14_11);
PN_model = Arc_P2T(PN_model,Phamch14_11,T2ham14_11);
PN_model = Arc_T2P(PN_model,T1ham14_11,p14);
PN_model = Arc_T2P(PN_model,T2ham14_11,p14);

