function PN_model = mabani()
[PN_model] = null_model_PN('mabani');


[PN_model,p9] = New_Place(PN_model,'mabani',0,1,{[0,1,0,0]});   %
[PN_model,Ptak9] = New_Place(PN_model,'mabani_taking',0,1,{});   %
[PN_model,Pgp0] = New_Place(PN_model,'mabani_passed',0,1,{});   %

[PN_model,t9] = New_Transition(PN_model,'mabani_taking_t1', 'General_func',1,5,0,1,120);	%
[PN_model,t559] = New_Transition(PN_model,'mabani_taking_t2', 'General_func',1,5,0,1,120);	%
[PN_model,tT9] = New_Transition(PN_model,'mabani_taking_s', 'General_func',1,5,0,1,120);	%
[PN_model,Tpas9] = New_Transition(PN_model,'mabani_passing', 'General_func',1,5,0,1,5);	%
[PN_model,Tfai9] = New_Transition(PN_model,'mabani_failling', 'General_func',1,5,0,1,2);	%

PN_model = Weighted_Arc_P2T(PN_model,p9,t9,1);	%PRESENT_PT_mabani
PN_model = Weighted_Arc_T2P(PN_model,t9,Ptak9,1);	%TAKING_TP_mabani
PN_model = Weighted_Arc_P2T(PN_model,p9,t559,1);	%PRESENT_PT_mabani
PN_model = Weighted_Arc_T2P(PN_model,t559,Ptak9,1);	%TAKING_TP_mabani
PN_model = Weighted_Arc_P2T(PN_model,p9,tT9,1);	%PRESENT_PT_mabani
PN_model = Weighted_Arc_T2P(PN_model,tT9,Ptak9,1);	%TAKING_TP_mabani
PN_model = Weighted_Arc_P2T(PN_model,Ptak9,Tpas9,1);	%Passing_PT_mabani
PN_model = Weighted_Arc_P2T(PN_model,Ptak9,Tfai9,1);	%Failling_PT_mabani
PN_model = Weighted_Arc_T2P(PN_model,Tpas9,Pgp0,3);	%pass_mabani
PN_model = Weighted_Arc_T2P(PN_model,Tfai9,p9,1);	%Failling_mabani
