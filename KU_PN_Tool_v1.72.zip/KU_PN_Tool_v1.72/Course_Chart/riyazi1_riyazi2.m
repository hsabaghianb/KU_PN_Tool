function PN_model = riyazi1_riyazi2()
[PN_model] = null_model_PN('riyazi1_riyazi2');

[PN_model,p1] = New_Place(PN_model,'riyazi1',0,1,{[0,1,0,0]});   %
[PN_model,Ptak1] = New_Place(PN_model,'riyazi1_taking',0,1,{});   %

[PN_model,p9] = New_Place(PN_model,'riyazi2',0,1,{[0,1,0,0]});   %
[PN_model,Ptak9] = New_Place(PN_model,'riyazi2_taking',0,1,{});   %
[PN_model,Pgp0] = New_Place(PN_model,'riyazi2_pass',0,1,{});   %


[PN_model,t1] = New_Transition(PN_model,'riyazi1_taking_t1', 'General_func',1,5,0,1,150);	%
[PN_model,t551] = New_Transition(PN_model,'riyazi1_taking_t2', 'General_func',1,5,0,1,150);	%
[PN_model,tT1] = New_Transition(PN_model,'riyazi1_taking_s', 'General_func',1,5,0,1,150);	%
[PN_model,Tpas1] = New_Transition(PN_model,'riyazi1_passing', 'General_func',1,5,0,1,5);	%
[PN_model,Tfai1] = New_Transition(PN_model,'riyazi1_failling', 'General_func',1,5,0,1,2);	%

[PN_model,t9] = New_Transition(PN_model,'riyazi2_taking_t1', 'General_func',1,5,0,1,120);	%
[PN_model,t559] = New_Transition(PN_model,'riyazi2_taking_t2', 'General_func',1,5,0,1,120);	%
[PN_model,tT9] = New_Transition(PN_model,'riyazi2_taking_s', 'General_func',1,5,0,1,120);	%
[PN_model,Tpas9] = New_Transition(PN_model,'riyazi2_passing', 'General_func',1,5,0,1,5);	%
[PN_model,Tfai9] = New_Transition(PN_model,'riyazi2_failling', 'General_func',1,5,0,1,2);	%

PN_model = Weighted_Arc_P2T(PN_model,p1,t1,1);	%PRESENT_PT_riyazi1
PN_model = Weighted_Arc_T2P(PN_model,t1,Ptak1,1);	%TAKING_TP_riyazi1
PN_model = Weighted_Arc_P2T(PN_model,p1,t551,1);	%PRESENT_PT_riyazi1
PN_model = Weighted_Arc_T2P(PN_model,t551,Ptak1,1);	%TAKING_TP_riyazi1
PN_model = Weighted_Arc_P2T(PN_model,p1,tT1,1);	%PRESENT_PT_riyazi1
PN_model = Weighted_Arc_T2P(PN_model,tT1,Ptak1,1);	%TAKING_TP_riyazi1
PN_model = Weighted_Arc_P2T(PN_model,Ptak1,Tpas1,1);	%Passing_PT_riyazi1
PN_model = Weighted_Arc_P2T(PN_model,Ptak1,Tfai1,1);	%Failling_PT_riyazi1
PN_model = Weighted_Arc_T2P(PN_model,Tpas1,p9,3);	%pass_riyazi1
PN_model = Weighted_Arc_T2P(PN_model,Tfai1,p1,1);	%Failling_riyazi1


PN_model = Weighted_Arc_P2T(PN_model,p9,t9,1);	%PRESENT_PT_riyazi2
PN_model = Weighted_Arc_T2P(PN_model,t9,Ptak9,1);	%TAKING_TP_riyazi2
PN_model = Weighted_Arc_P2T(PN_model,p9,t559,1);	%PRESENT_PT_riyazi2
PN_model = Weighted_Arc_T2P(PN_model,t559,Ptak9,1);	%TAKING_TP_riyazi2
PN_model = Weighted_Arc_P2T(PN_model,p9,tT9,1);	%PRESENT_PT_riyazi2
PN_model = Weighted_Arc_T2P(PN_model,tT9,Ptak9,1);	%TAKING_TP_riyazi2
PN_model = Weighted_Arc_P2T(PN_model,Ptak9,Tpas9,1);	%Passing_PT_riyazi2
PN_model = Weighted_Arc_P2T(PN_model,Ptak9,Tfai9,1);	%Failling_PT_riyazi2
PN_model = Weighted_Arc_T2P(PN_model,Tpas9,Pgp0,3);	%pass_riyazi2
PN_model = Weighted_Arc_T2P(PN_model,Tfai9,p9,1);	%Failling_riyazi2
