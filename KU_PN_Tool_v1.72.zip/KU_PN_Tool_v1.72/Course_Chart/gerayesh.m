function PN_model = gerayesh()
[PN_model] = null_model_PN('gerayesh');

[PN_model,Pgp6] = New_Place(PN_model,'gerayesh_chosen',0,1,{[0,1,0,0]});
[PN_model,p70] = New_Place(PN_model,'Gerayesh_&narm',0,1,{[0,1,0,0]});   %
[PN_model,p98] = New_Place(PN_model,'Gerayesh_&memari',0,1,{[0,1,0,0]});   %
[PN_model,t70] = New_Transition(PN_model,'&narm_gerayesh_choosing', 'General_func',1,30,0,1,1);	%
[PN_model,t98] = New_Transition(PN_model,'&memari_gerayesh_choosing', 'General_func',1,30,0,1,1);	%

PN_model = Weighted_Arc_P2T(PN_model,p70,t70,1);	%Gerayesh_choosing_70
PN_model = Weighted_Arc_P2T(PN_model,Pgp6,t70,1);	%Gerayesh_choosing_70
PN_model = Weighted_Arc_P2T(PN_model,p98,t98,1);	%Gerayesh_choosing_98
PN_model = Weighted_Arc_P2T(PN_model,Pgp6,t98,1);	%Gerayesh_choosing_98
	