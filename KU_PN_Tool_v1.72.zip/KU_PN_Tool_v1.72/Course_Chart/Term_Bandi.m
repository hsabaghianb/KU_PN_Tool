function PN_model = Gosasteh_mantghi()
[PN_model] = null_model_PN('Term_Bandi');

%Term & Type Place Def
[PN_model,Pterm71] = New_Place(PN_model,'S_Term1',0,1,{[0,1,0,0]});
[PN_model,Pterm51] = New_Place(PN_model,'H_term1',0,1,{});
[PN_model,Pterm61] = New_Place(PN_model,'term1',0,1,{});
[PN_model,Pterm72] = New_Place(PN_model,'S_term2',0,1,{});
[PN_model,Pterm52] = New_Place(PN_model,'H_term2',0,1,{});
[PN_model,Pterm62] = New_Place(PN_model,'term2',0,1,{});
[PN_model,Pterm7T] = New_Place(PN_model,'S_termT',0,1,{});
[PN_model,Pterm5T] = New_Place(PN_model,'H_termT',0,1,{});
[PN_model,Pterm6T] = New_Place(PN_model,'termT',0,1,{});


%Transition Definition 
[PN_model,Tterm71] = New_Transition(PN_model,'term1', 'General_func',1,0,0,1,1);	%
[PN_model,Tterm61] = New_Transition(PN_model,'During_term1', 'General_func',1,10,0,1,1);	%
[PN_model,Tterm72] = New_Transition(PN_model,'term2', 'General_func',1,0,0,1,1);	%
[PN_model,Tterm62] = New_Transition(PN_model,'During_term2', 'General_func',1,10,0,1,1);	%
[PN_model,Tterm7T] = New_Transition(PN_model,'termT', 'General_func',1,0,0,1,1);	%
[PN_model,Tterm6T] = New_Transition(PN_model,'During_termT', 'General_func',1,10,0,1,1);	%

%Arc Definition3 
PN_model = Weighted_Arc_P2T(PN_model,Pterm71,Tterm71,1);	%Beginning_Term1
PN_model = Weighted_Arc_T2P(PN_model,Tterm71,Pterm61,20);	%Taking_Term
PN_model = Weighted_Arc_T2P(PN_model,Tterm71,Pterm51,1);	%Arc_1_Term1
PN_model = Weighted_Arc_P2T(PN_model,Pterm51,Tterm61,1);	%Arc_2_Term1
PN_model = Weighted_Arc_P2T(PN_model,Pterm72,Tterm72,1);	%Beginning_Term2
PN_model = Weighted_Arc_T2P(PN_model,Tterm72,Pterm62,20);	%Taking_Term
PN_model = Weighted_Arc_T2P(PN_model,Tterm72,Pterm52,1);	%Arc_1_Term2
PN_model = Weighted_Arc_P2T(PN_model,Pterm52,Tterm62,1);	%Arc_2_Term2
PN_model = Weighted_Arc_P2T(PN_model,Pterm7T,Tterm7T,1);	%Beginning_TermT
PN_model = Weighted_Arc_T2P(PN_model,Tterm7T,Pterm6T,6);	%Taking_Term
PN_model = Weighted_Arc_T2P(PN_model,Tterm7T,Pterm5T,1);	%Arc_1_TermT
PN_model = Weighted_Arc_P2T(PN_model,Pterm5T,Tterm6T,1);	%Arc_2_TermT
PN_model = Weighted_Arc_T2P(PN_model,Tterm61,Pterm72,1);	%Beginning_Term
PN_model = Weighted_Arc_T2P(PN_model,Tterm62,Pterm7T,1);	%Beginning_Term
PN_model = Weighted_Arc_T2P(PN_model,Tterm6T,Pterm71,1);	%Beginning_Term


